<div class="mkd-social-share-holder mkd-list">
	<ul>
		<?php foreach($networks as $net) {
			echo anahata_mikado_get_module_part($net);
		} ?>
	</ul>
</div>