<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/clients-boxes/clients-boxes.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/clients-boxes/clients-boxes-item.php';