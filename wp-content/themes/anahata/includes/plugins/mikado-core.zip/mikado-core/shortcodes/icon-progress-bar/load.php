<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/icon-progress-bar/icon-progress-bar.php';