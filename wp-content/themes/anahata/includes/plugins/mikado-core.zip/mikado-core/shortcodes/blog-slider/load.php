<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/blog-slider/blog-slider.php';