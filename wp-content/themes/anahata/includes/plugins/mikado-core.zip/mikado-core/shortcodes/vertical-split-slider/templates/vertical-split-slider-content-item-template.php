<div class="mkd-vss-ms-section" <?php anahata_mikado_inline_style($content_style);?> <?php echo anahata_mikado_get_inline_attrs($content_data); ?>>
	<?php echo do_shortcode($content); ?>
</div>