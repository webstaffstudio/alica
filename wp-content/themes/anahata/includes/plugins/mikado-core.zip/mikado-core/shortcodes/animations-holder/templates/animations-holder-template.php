<div <?php anahata_mikado_class_attribute($class); ?> <?php echo anahata_mikado_get_inline_attrs($data); ?>>
	<div <?php anahata_mikado_inline_style($style); ?>>
		<?php echo do_shortcode($content); ?>
	</div>

</div>