<div class="mkd-team-slider-holder<?php echo esc_attr($show_bullets)?><?php echo esc_attr($light_nav)?>">
    <div class="mkd-team-slider-holder-inner">
        <div class="mkd-team-slider" <?php echo anahata_mikado_get_inline_attrs($data_attribute) ?>>
            <?php echo do_shortcode($content); ?>
        </div>
    </div>
</div>