<div class="mkd-separator-holder clearfix  <?php echo esc_attr($separator_class); ?>">
	<div class="mkd-separator" <?php echo anahata_mikado_get_inline_style($separator_style); ?>></div>
</div>
