<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/cards-slider/cards-slider.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/cards-slider/cards-slider-item.php';