<?php
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/process-slider/process-slider.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/process-slider/process-slider-item.php';