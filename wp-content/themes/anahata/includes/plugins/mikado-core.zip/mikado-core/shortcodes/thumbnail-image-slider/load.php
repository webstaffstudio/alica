<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/thumbnail-image-slider/thumbnail-image-slider.php';